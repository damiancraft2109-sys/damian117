// 1. SELECCIÓN DE AUTO
switch (opcionAuto) {
    case 1: // Nissan Skyline
        
        // 2. CATEGORÍAS DEL TALLER
        switch (opcionTaller) {
            case 3: // Pintura
                
                // 3. SUBMENÚ PINTURA
                switch (opcionEstetica) {
                    case 1: // Opción de Pintura tradicional
                        
                        // 4. BUCLE FOR: Listar los colores en pantalla
                        String[] colores = {"Rojo", "Azul", "Verde", "Negro", "Blanco"};
                        for (int i = 0; i < colores.length; i++) {
                            // Aquí el código dibuja o muestra el color actual: colores[i]
                        }
                        
                        // 5. ESTRUCTURA IF: Validar fondos tras elegir un color
                        if (creditosJugador >= costoPintura) {
                            
                            // CONFIRMACIÓN (Ocurre dentro del IF)
                            creditosJugador -= costoPintura;
                            colorAuto = colorSeleccionado;
                            // El jugador puede comprar pintura
                            
                        } else {
                            // Créditos insuficientes
                        }
                        break;
                        
                    case 2: // Vinilos
                        break;
                    case 3: // Patrocinadores
                        break;
                }
                break; // Fin de categoría Pintura
                
            case 1: // Partes físicas
                break;
        }
        break; // Fin de auto 1
}
